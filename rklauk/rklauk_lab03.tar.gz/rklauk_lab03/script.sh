#!/bin/bash
hostname
whoami
echo "Hello, World!"
pwd
mkdir dirA dirB dirC
ls -d dirA dirB dirC
touch dirA/fileA dirB/fileB dirC/fileC
ls dirA
ls dirB
ls dirC
rm -r dirA dirB dirC
